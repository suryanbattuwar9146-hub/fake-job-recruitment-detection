import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import pickle

df = pd.read_csv("fake_job_postings.csv")
X = df["description"]
y = df["fraudulent"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

tfidf = TfidfVectorizer(stop_words='english', max_features=5000)
X_train = tfidf.fit_transform(X_train)
X_test = tfidf.transform(X_test)

model = LogisticRegression()
model.fit(X_train, y_train)

pickle.dump(model, open("model/model.pkl", "wb"))
pickle.dump(tfidf, open("model/vectorizer.pkl", "wb"))

print("Training completed!")
