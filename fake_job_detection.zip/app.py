from flask import Flask, render_template, request
import pickle

app = Flask(__name__)

model = pickle.load(open("model/model.pkl", "rb"))
vectorizer = pickle.load(open("model/vectorizer.pkl", "rb"))

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    job_desc = request.form['job_text']
    vector = vectorizer.transform([job_desc])
    prediction = model.predict(vector)[0]
    result_text = "Fake Job" if prediction == 1 else "Real Job"
    return render_template("index.html", prediction=result_text)

if __name__ == "__main__":
    app.run(debug=True)
